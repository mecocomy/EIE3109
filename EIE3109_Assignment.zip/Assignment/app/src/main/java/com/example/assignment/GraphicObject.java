package com.example.assignment;

import android.graphics.Bitmap;

import java.util.Random;

public class GraphicObject {
    private Bitmap bitmap;
    private Coordinates coordinates;
    private Movement movement;
    private Random random = new Random();
    public GraphicObject (Bitmap bitmap) {
        this.bitmap = bitmap;
        this.coordinates = new Coordinates(bitmap);
        int randomXSpeed = random.nextInt(5) + 1;
        int randomYSpeed = random.nextInt(5) + 1;
        this.movement = new Movement();
        this.movement.setXYSpeed(randomXSpeed,randomYSpeed);
    }

    public Bitmap getGraphic() {
        return bitmap;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public Movement getMovement() {
        return movement;
    }

}
