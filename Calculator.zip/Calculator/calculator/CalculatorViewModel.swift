//
//  CalculatorViewModel.swift
//  calculator
//
//  Created by EIE3109 ZengMengyuan on 17/10/2023.
//

import Foundation
import SwiftUI

class CalculatorViewModel:ObservableObject{
    
    @Published var value = "0"
    @Published var mode = ["DEC", "BIN", "HEX"]
    @Published var selectedMode = "DEC"{
        didSet{
            switch selectedMode{
            case "BIN":
                value = String(Int(value) ?? 0, radix:2)
            case "HEX":
                value = String(Int(value) ?? 0, radix: 16, uppercase:true)
            default:
                value = "\(accumulator)"
            }
        }
        willSet{
            value = String(format:"%.0f",accumulator)
        }
    }
    
    private var isUserEnteringNumber = false
    
    private var firstOperation: String?
    
    private var pendingFirstBinaryOperation:PendingBinaryOperation?
    
    private var pendingSecondBinaryOperation: PendingBinaryOperation?
    
    private enum Operation{
        case constant(Double)
        case binaryOperation((Double, Double)->Double)
        case unaryOperation((Double) -> Double)
        case equals
        case zeroclr
    }
    
    private var operations: Dictionary<String, Operation> = [
        CalcuButton.pi.rawValue: Operation.constant(Double.pi),
        CalcuButton.e.rawValue:Operation.constant(M_E),
        CalcuButton.add.rawValue: Operation.binaryOperation({$0+$1}),
        CalcuButton.subtract.rawValue: Operation.binaryOperation({$0-$1}),
        CalcuButton.multiply.rawValue: Operation.binaryOperation({$0*$1}),
        CalcuButton.divide.rawValue: Operation.binaryOperation({$0/$1}),
        CalcuButton.percent.rawValue: Operation.unaryOperation({$0 / 100}),
        CalcuButton.negative.rawValue: Operation.unaryOperation({-$0}),
        CalcuButton.sin.rawValue: Operation.unaryOperation(sin),
        CalcuButton.cos.rawValue: Operation.unaryOperation(cos),
        CalcuButton.equal.rawValue: Operation.equals,
        CalcuButton.clear.rawValue: Operation.zeroclr,
        CalcuButton.p.rawValue: Operation.unaryOperation({pow($0, 2)})
    ]
    
    private func performPendingBinaryOperation(){
        if pendingSecondBinaryOperation != nil {
            //2ndPBO is not nil
            //calculate 2ndPBO first, then 1stPBO
            //ex.1+2*3 1stPBO=1+, 2ndPBO=2*, acc=3
            accumulator = pendingSecondBinaryOperation?.perform(with: accumulator) ?? 0
            accumulator = pendingFirstBinaryOperation?.perform(with: accumulator) ?? 0
            pendingSecondBinaryOperation = nil
            pendingFirstBinaryOperation = nil
        } else if pendingFirstBinaryOperation != nil {
            accumulator =
            pendingFirstBinaryOperation?.perform(with: accumulator) ?? 0
            pendingFirstBinaryOperation = nil
        }
    }
    
    private struct PendingBinaryOperation{
        let function: (Double, Double)->Double
        let firstOperand: Double
        
        func perform(with secondOperand: Double) -> Double{
            return function(firstOperand, secondOperand)
        }
    }
    
    private struct PendingFirstBinaryOperation{
        let function: (Double, Double)->Double
        let firstOperand: Double
        
        func perform(with secondOperand: Double) -> Double{
            return function(firstOperand, secondOperand)
        }
    }
    
    private struct PendingSecondBinaryOperation{
        let function: (Double, Double)->Double
        let firstOperand: Double
        
        func perform(with secondOperand: Double) -> Double{
            return function(firstOperand, secondOperand)
        }
    }
    private var accumulator: Double {
        set{
            if newValue == 0{
                self.value = "0"
            }else{
                if selectedMode == "BIN"{
                    self.value = String(Int(newValue), radix: 2)
                }else if selectedMode == "DEC"{
                    self.value = "\(newValue)"
                }else if selectedMode == "HEX"{
                    self.value = String(Int(newValue), radix : 16).uppercased()
                }
            }
        }
        get{
            if selectedMode == "BIN"{
                return Double(Int(value, radix:2) ?? 0)
            }
            if selectedMode == "HEX"{
                return Double(Int(value, radix: 16) ?? 0)
            }
            return Double(value) ?? 0
        }
    }
    
    let buttons:[[CalcuButton]] = [
        [.pi, .e, .sin, .cos],
        [.clear, .negative, .percent, .divide],
        [.seven, .eight, .nine, .multiply],
        [.four, .five, .six, .subtract],
        [.one, .two, .three, .add],
        [.zero, .decimal, .p, .equal]
    ]
    let button1:[[CalcuButton]] = [
        [.add, .subtract, .multiply, .divide],
        [.zero, .one, .equal, .clear]
    ]
    let button2:[[CalcuButton]] = [
        [.clear, .equal],
        [.add, .subtract, .multiply, .divide],
        [.seven, .eight, .nine, .F],
        [.four, .five, .six, .E],
        [.one, .two, .three, .D],
        [.zero, .A, .B, .C]
    ]
    let button3: [[CalcuButton]] = [
        [.seven, .eight, .nine,.divide, .clear, .pi],
        [.four, .five, .six, .multiply, .cos, .e],
        [.one, .two, .three, .subtract, .sin, .negative],
        [.zero, .decimal, .add, .equal, .percent]
    ]
    func didTap(button: CalcuButton){
        if button.isDigit == true{
            digitPressed(button:button)
        }
        else{
            operationPressed(button:button)
        }
    }
    
    func digitPressed(button: CalcuButton){
        let number = button.rawValue
        if isUserEnteringNumber == false{
            if number != "0"{
                self.value = number
                isUserEnteringNumber = true
            }
            if number == "."{
                self.value = "0."
                isUserEnteringNumber = true
            }
        }
        else{
            if number == "."{
                if !self.value.contains("."){
                    self.value = "\(self.value)\(number)"
                }
            }
            else{
                self.value = "\(self.value)\(number)"
            }
        }
    }
    
    func operationPressed(button: CalcuButton){
        isUserEnteringNumber = false
        var res:Double
        if let operation = operations[button.rawValue]{
            switch operation{
            case .constant(let resultValue):
                accumulator = resultValue
            case .binaryOperation(let function):
                if pendingSecondBinaryOperation == nil {
                    if pendingFirstBinaryOperation == nil {
                        pendingFirstBinaryOperation = PendingBinaryOperation(function:function, firstOperand: accumulator)
                        firstOperation = button.rawValue
                    } else {
                        if firstOperation == CalcuButton.multiply.rawValue || firstOperation == CalcuButton.divide.rawValue {
                            res = pendingFirstBinaryOperation?.perform(with: accumulator) ?? 0
                            pendingFirstBinaryOperation = PendingBinaryOperation(function: function, firstOperand: res)
                            firstOperation = button.rawValue
                            accumulator = res
                        } else {
                            if button == CalcuButton.add || button == CalcuButton.subtract {
                                res = pendingFirstBinaryOperation?.perform(with: accumulator) ?? 0
                                pendingFirstBinaryOperation = PendingBinaryOperation(function: function, firstOperand: res)
                                firstOperation = button.rawValue
                                performPendingBinaryOperation()
                                pendingFirstBinaryOperation = PendingBinaryOperation(function: function, firstOperand: accumulator)
                            } else {
                                pendingSecondBinaryOperation = PendingBinaryOperation(function: function, firstOperand: accumulator)
                            }
                        }
                    }
                } else {
                    res = pendingSecondBinaryOperation?.perform(with: accumulator) ?? 0
                    if button == CalcuButton.multiply || button == CalcuButton.divide
                    {
                        pendingSecondBinaryOperation=PendingBinaryOperation(function:function, firstOperand: res)
                    } else {
                        res = pendingSecondBinaryOperation?.perform(with: res) ?? 0
                        pendingFirstBinaryOperation = PendingBinaryOperation(function: function, firstOperand: res)
                        firstOperation = button.rawValue
                        pendingSecondBinaryOperation = nil
                    }
                    accumulator = res
                }
            case .unaryOperation(let function):
                accumulator = function(accumulator)
            case .equals:
                performPendingBinaryOperation()
            case .zeroclr:
                zeroclr()
            }
        }
    }
    
    func zeroclr(){
        accumulator = 0;
        pendingFirstBinaryOperation = nil
        pendingSecondBinaryOperation = nil
    }
}

