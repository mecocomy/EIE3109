//
//  calculatorApp.swift
//  calculator
//
//  Created by EIE3109 on 17/10/2023.
//

import SwiftUI

@main
struct calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
