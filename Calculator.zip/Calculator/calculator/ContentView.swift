//
//  ContentView.swift
//  Calculator
//
//  Created by EIE3109 Zeng Mengyuan on 3/10/2023.
//

import SwiftUI

struct DeviceRotationViewModifier: ViewModifier{
    let action: (UIDeviceOrientation) -> Void
    func body(content: Content) -> some View{
        content.onAppear().onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in action(UIDevice.current.orientation)
        }
    }
}

extension View {
    func onRotate(perform action: @escaping (UIDeviceOrientation) -> Void) -> some View {
        self.modifier(DeviceRotationViewModifier(action: action))
    }
}

struct ContentView: View {
    @State private var orientation = UIDeviceOrientation.unknown
    @StateObject private var calculatorVM = CalculatorViewModel()
    func buttonWidth(item : CalcuButton) -> CGFloat{
        let width = (UIScreen.main.bounds.width - (5*12))/4
        if UIDevice.current.userInterfaceIdiom == .pad{
            return width/2
        }
        if orientation.isLandscape{
            let w = (UIScreen.main.bounds.height - 5*12)/4
            if item == .zero{
                return (w*2+12)/2
            }
            return w/2
        }
        if calculatorVM.selectedMode == "DEC"{
            }
        
        return width
    }
    func buttonHeight() -> CGFloat{
        let height=(UIScreen.main.bounds.width - (5*12))/4
        if orientation.isLandscape{
            let h = (UIScreen.main.bounds.height - 5*12)/4
            return h/2
        }
        if  UIDevice.current.userInterfaceIdiom == .pad{
            return height/2
        }
        
        return height
    }
    
    
    var body: some View {
        Group{
            if orientation.isPortrait{
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    VStack{
                        Text("Mode:\(calculatorVM.selectedMode)").font(.system(size:20)).foregroundColor(.white).padding()
                        Picker("Mode", selection: $calculatorVM.selectedMode){
                            ForEach(calculatorVM.mode , id:\.self){
                                Text($0)
                            }
                        }.pickerStyle(.segmented).background(Color.blue)
                        HStack{
                            Spacer()
                            Text(calculatorVM.value)
                                .bold().font(.system(size:100)).foregroundColor(.white)
                        }
                        .padding()
                        //Buttons
                        if calculatorVM.selectedMode == "DEC"{
                            ForEach (calculatorVM.buttons, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        else if calculatorVM.selectedMode == "BIN"{
                            ForEach (calculatorVM.button1, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        else if calculatorVM.selectedMode == "HEX"{
                            ForEach (calculatorVM.button2, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        
                        
                    }
                }
            }
            else if orientation.isLandscape{
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    VStack{
                        Text("Mode:\(calculatorVM.selectedMode)").font(.system(size:20)).foregroundColor(.white).padding()
                        Picker("Mode", selection: $calculatorVM.selectedMode){
                            ForEach(calculatorVM.mode , id:\.self){
                                Text($0)
                            }
                        }.pickerStyle(.segmented).background(Color.blue)
                        HStack{
                            Spacer()
                            Text(calculatorVM.value)
                                .bold().font(.system(size:50)).foregroundColor(.white)
                        }
                        .padding()
                        if calculatorVM.selectedMode == "DEC"{
                            ForEach (calculatorVM.button3, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:16)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                    }
                    
                    
                }
            }
            
            else {
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    VStack{
                        Text("Mode:\(calculatorVM.selectedMode)").font(.system(size:20)).foregroundColor(.white).padding()
                        Picker("Mode", selection: $calculatorVM.selectedMode){
                            ForEach(calculatorVM.mode , id:\.self){
                                Text($0)
                            }
                        }.pickerStyle(.segmented).background(Color.blue)
                        HStack{
                            Spacer()
                            Text(calculatorVM.value)
                                .bold().font(.system(size:100)).foregroundColor(.white)
                        }
                        .padding()
                        //Buttons
                        if calculatorVM.selectedMode == "DEC"{
                            ForEach (calculatorVM.buttons, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        else if calculatorVM.selectedMode == "BIN"{
                            ForEach (calculatorVM.button1, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        else if calculatorVM.selectedMode == "HEX"{
                            ForEach (calculatorVM.button2, id: \.self){
                                row in
                                HStack(spacing:12){
                                    ForEach(row, id: \.self){ item in
                                        Button(action:{
                                            print (item.rawValue)
                                            calculatorVM.didTap(button: item)
                                        }, label:{
                                            Text(item.rawValue).font(.system(size:32)).frame(width:self.buttonWidth(item:item), height:self.buttonHeight()).background(item.buttonColor).foregroundColor(.white).cornerRadius(self.buttonHeight()/2)
                                            
                                        })
                                    }
                                }
                                .padding(.bottom, 3)
                            }
                        }
                        
                        
                    }
                }
            }
            
        }.onRotate{ newOrentation in orientation = newOrentation
        }
    }
}

            
#Preview {
    ContentView()
}
